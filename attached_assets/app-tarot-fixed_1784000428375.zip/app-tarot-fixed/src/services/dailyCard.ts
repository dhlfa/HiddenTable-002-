import type { DailyCard, Orientation } from '../types';
import { tarotCards } from '../data/cards';
import { getTodayKey } from '../utils/date';

const STORAGE_KEY = 'the-hidden-table:daily-card';

export function getOrCreateDailyCard(): DailyCard {
  const today = getTodayKey();
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed: DailyCard = JSON.parse(stored);
      if (parsed.date === today) return parsed;
    }
  } catch { /* ignore */ }

  const card = tarotCards[Math.floor(Math.random() * tarotCards.length)];
  const orientation: Orientation = Math.random() > 0.5 ? 'upright' : 'reversed';
  const reflection = orientation === 'upright' ? card.upright : card.reversed;
  const daily: DailyCard = { date: today, card, orientation, reflection };
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(daily)); } catch { /* ignore */ }
  return daily;
}
