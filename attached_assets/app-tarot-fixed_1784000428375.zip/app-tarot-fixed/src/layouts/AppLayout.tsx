import { useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import { AmbientBackground } from '../components/ui/AmbientBackground';
import { SoundToggle } from '../components/ui/SoundToggle';
import { useSettings } from '../hooks/useSettings';
import { soundManager } from '../services/sound';

export function AppLayout() {
  const { settings } = useSettings();

  useEffect(() => {
    soundManager.setEnabled(settings.soundEnabled);
    soundManager.setVolume(settings.volume);
  }, [settings.soundEnabled, settings.volume]);

  return (
    <div className="min-h-screen relative">
      <AmbientBackground intensity={settings.animationIntensity} />
      <div className="absolute top-4 right-4 z-50"><SoundToggle /></div>
      <Outlet />
    </div>
  );
}
