import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PageTransition } from '../components/ui/PageTransition';
import { BackButton } from '../components/ui/BackButton';
import { SectionTitle } from '../components/ui/SectionTitle';
import { MysticButton } from '../components/ui/MysticButton';
import { TarotCard } from '../components/cards/CardFaces';
import { CardBack } from '../components/cards/CardFaces';
import { getOrCreateDailyCard } from '../services/dailyCard';
import { useJournal } from '../hooks/useJournal';
import { useSettings } from '../hooks/useSettings';
import { useReducedMotion } from '../hooks/useReducedMotion';
import { soundManager } from '../services/sound';
import { getTodayDisplayDate } from '../utils/date';
import type { DailyCard, ReadingResult } from '../types';

export function DailyReflection() {
  const { settings } = useSettings();
  const reducedMotion = useReducedMotion(settings.reduceMotion);
  const { save } = useJournal();
  const [dailyCard, setDailyCard] = useState<DailyCard | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const dc = getOrCreateDailyCard();
    setDailyCard(dc);
    const sessionKey = `the-hidden-table:daily-revealed:${dc.date}`;
    if (sessionStorage.getItem(sessionKey) === 'true') setRevealed(true);
  }, []);

  const handleReveal = () => {
    if (!dailyCard) return;
    soundManager.play('flip');
    setRevealed(true);
    sessionStorage.setItem(`the-hidden-table:daily-revealed:${dailyCard.date}`, 'true');
  };

  const handleSaveToJournal = () => {
    if (!dailyCard) return;
    const result: ReadingResult = {
      id: `daily-${dailyCard.date}`, date: new Date().toISOString(),
      question: 'Daily Reflection', category: 'General', spreadId: 'one-card', spreadName: 'Daily Reflection',
      cards: [{ card: dailyCard.card, orientation: dailyCard.orientation, positionIndex: 0, positionName: 'Reflection' }],
      overallReflection: dailyCard.reflection, positionMeanings: [{ positionName: 'Reflection', meaning: dailyCard.reflection }],
      patternBetweenCards: 'With a single card, the pattern is the card itself.',
      reflection: dailyCard.reflection, considerations: "Consider how this card's energy is already present in your day.",
    };
    save(result); setSaved(true); soundManager.play('click');
  };

  return (
    <PageTransition>
      <div className="min-h-screen px-4 py-6 md:py-8">
        <div className="max-w-2xl mx-auto">
          <BackButton />
          <SectionTitle className="mt-6">Daily Reflection</SectionTitle>
          <p className="text-center font-cormorant text-lg text-muted italic mb-8">{getTodayDisplayDate()}</p>
          <div className="flex flex-col items-center">
            <AnimatePresence mode="wait">
              {!revealed ? (
                <motion.div key="unrevealed" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="flex flex-col items-center">
                  <motion.div animate={reducedMotion ? {} : { y: [0, -4, 0] }} transition={reducedMotion ? {} : { duration: 5, repeat: Infinity, ease: 'easeInOut' }} className="mb-8"><CardBack size="lg" /></motion.div>
                  <MysticButton variant="primary" size="lg" onClick={handleReveal}>Reveal Today's Card</MysticButton>
                </motion.div>
              ) : (
                <motion.div key="revealed" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }} className="flex flex-col items-center">
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: [0, 0.4, 0.2] }} transition={{ duration: 2, ease: 'easeOut' }} className="absolute"
                    style={{ width: 200, height: 200, background: `radial-gradient(circle, ${dailyCard?.card.accentColor}20 0%, transparent 70%)` }} />
                  <TarotCard card={dailyCard?.card} orientation={dailyCard?.orientation} revealed size="lg" />
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.5 }} className="text-center mt-6 max-w-md">
                    <h3 className="font-cinzel text-xl text-cream mb-1">{dailyCard?.card.name}</h3>
                    <p className="font-cormorant text-sm text-gold-light mb-4">{dailyCard?.orientation === 'reversed' ? 'Reversed' : 'Upright'}</p>
                    <p className="font-cormorant text-lg text-cream/70 leading-relaxed italic">{dailyCard?.reflection}</p>
                  </motion.div>
                  <div className="mt-8">
                    <MysticButton variant="outline" size="md" onClick={handleSaveToJournal} disabled={saved}>{saved ? 'Saved to Journal' : 'Save to Journal'}</MysticButton>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
