import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Trash2, X } from 'lucide-react';
import { PageTransition } from '../components/ui/PageTransition';
import { BackButton } from '../components/ui/BackButton';
import { SectionTitle } from '../components/ui/SectionTitle';
import { MysticButton } from '../components/ui/MysticButton';
import { MarkdownRenderer } from '../components/ui/MarkdownRenderer';
import { TarotCard } from '../components/cards/CardFaces';
import { useJournal } from '../hooks/useJournal';
import { formatDate } from '../utils/date';
import { spreads } from '../data/spreads';
import type { ReadingResult } from '../types';

export function ReadingJournal() {
  const navigate = useNavigate();
  const { entries, remove, clearAll } = useJournal();
  const [search, setSearch] = useState('');
  const [spreadFilter, setSpreadFilter] = useState('all');
  const [selected, setSelected] = useState<ReadingResult | null>(null);
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);

  const filtered = useMemo(() => entries.filter((e) => {
    const matchesSearch = !search || e.question.toLowerCase().includes(search.toLowerCase()) || e.spreadName.toLowerCase().includes(search.toLowerCase());
    const matchesSpread = spreadFilter === 'all' || e.spreadId === spreadFilter;
    return matchesSearch && matchesSpread;
  }), [entries, search, spreadFilter]);

  return (
    <PageTransition>
      <div className="min-h-screen px-4 py-6 md:py-8">
        <div className="max-w-4xl mx-auto">
          <BackButton />
          <SectionTitle className="mt-6 mb-6">Reading Journal</SectionTitle>

          <div className="relative max-w-md mx-auto mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" strokeWidth={1.5} />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search readings..."
              className="w-full glass-panel rounded-full pl-10 pr-4 py-2.5 text-sm text-cream font-inter placeholder:text-muted/50 focus:outline-none focus:border-gold/30 transition-colors" />
          </div>

          <div className="flex flex-wrap justify-center gap-2 mb-6">
            <button onClick={() => setSpreadFilter('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-inter transition-all touch-target ${spreadFilter === 'all' ? 'bg-gold/20 border border-gold/50 text-cream' : 'bg-midnight-light/40 border border-cream/10 text-muted hover:border-gold/20'}`}>All</button>
            {spreads.map((s) => (
              <button key={s.id} onClick={() => setSpreadFilter(s.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-inter transition-all touch-target ${spreadFilter === s.id ? 'bg-gold/20 border border-gold/50 text-cream' : 'bg-midnight-light/40 border border-cream/10 text-muted hover:border-gold/20'}`}>{s.name}</button>
            ))}
          </div>

          {filtered.length === 0 ? (
            <div className="text-center py-12">
              <p className="font-cormorant text-lg text-muted italic mb-4">No readings yet.</p>
              <MysticButton variant="outline" onClick={() => navigate('/reading')}>Begin a Reading</MysticButton>
            </div>
          ) : (
            <div className="space-y-3">
              <AnimatePresence>
                {filtered.map((entry) => (
                  <motion.button key={entry.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9 }} transition={{ duration: 0.3 }} onClick={() => setSelected(entry)}
                    className="w-full glass-panel rounded-xl p-4 text-left hover:border-gold/30 transition-all touch-target">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="font-cinzel text-sm text-cream truncate">{entry.question || 'Daily Reflection'}</p>
                        <p className="font-inter text-xs text-muted mt-1">{entry.spreadName} · {formatDate(entry.date)}</p>
                        {entry.readingId && <p className="font-inter text-[10px] text-gold/40 mt-1">{entry.readingId}</p>}
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        {entry.cards.slice(0, 3).map((c, i) => (
                          <div key={i} className="w-8 h-12 rounded border border-gold/20 flex items-center justify-center"
                            style={{ background: 'linear-gradient(135deg, #151C2E 0%, #0E1426 100%)' }}>
                            <span className="font-cinzel text-[8px]" style={{ color: `${c.card.accentColor}80` }}>✦</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.button>
                ))}
              </AnimatePresence>
            </div>
          )}

          {entries.length > 0 && (
            <div className="text-center mt-8">
              <button onClick={() => setConfirmDeleteAll(true)}
                className="font-inter text-xs text-muted hover:text-red-400 transition-colors touch-target inline-flex items-center gap-1.5">
                <Trash2 className="w-3.5 h-3.5" strokeWidth={1.5} /> Delete All
              </button>
            </div>
          )}
        </div>

        {/* Detail Modal */}
        <AnimatePresence>
          {selected && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelected(null)}
              className="fixed inset-0 bg-midnight/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()} className="glass-panel rounded-2xl p-6 max-w-lg w-full max-h-[80vh] overflow-y-auto relative">
                <button onClick={() => setSelected(null)} className="absolute top-4 right-4 text-muted hover:text-cream transition-colors touch-target">
                  <X className="w-5 h-5" strokeWidth={1.5} />
                </button>
                <h3 className="font-cinzel text-lg text-cream mb-1">{selected.question || 'Daily Reflection'}</h3>
                <p className="font-inter text-xs text-muted mb-4">{selected.spreadName} · {formatDate(selected.date)}</p>
                {selected.readingId && <p className="font-inter text-[10px] text-gold/40 mb-4">{selected.readingId}</p>}
                <div className="flex flex-wrap justify-center gap-3 mb-4">
                  {selected.cards.map((c, i) => (
                    <div key={i} className="flex flex-col items-center gap-1">
                      <TarotCard card={c.card} orientation={c.orientation} revealed size="sm" />
                      <p className="font-cinzel text-[10px] text-gold-light">{c.positionName}</p>
                    </div>
                  ))}
                </div>
                {selected.reflection && (
                  <div className="mt-4">
                    <MarkdownRenderer content={selected.reflection} className="space-y-1" />
                  </div>
                )}
                <div className="mt-6 flex justify-center">
                  <button onClick={() => { remove(selected.id); setSelected(null); }}
                    className="font-inter text-xs text-muted hover:text-red-400 transition-colors touch-target inline-flex items-center gap-1.5">
                    <Trash2 className="w-3.5 h-3.5" strokeWidth={1.5} /> Delete Reading
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Delete All Confirmation */}
        <AnimatePresence>
          {confirmDeleteAll && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setConfirmDeleteAll(false)}
              className="fixed inset-0 bg-midnight/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()} className="glass-panel rounded-2xl p-6 max-w-sm w-full text-center">
                <p className="font-cormorant text-lg text-cream/80 italic mb-6">Delete all readings? This cannot be undone.</p>
                <div className="flex gap-3 justify-center">
                  <MysticButton variant="ghost" onClick={() => setConfirmDeleteAll(false)}>Cancel</MysticButton>
                  <MysticButton variant="danger" onClick={() => { clearAll(); setConfirmDeleteAll(false); }}>Delete All</MysticButton>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </PageTransition>
  );
}
