import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Volume2, VolumeX, RotateCcw } from 'lucide-react';
import { PageTransition } from '../components/ui/PageTransition';
import { BackButton } from '../components/ui/BackButton';
import { SectionTitle } from '../components/ui/SectionTitle';
import { MysticButton } from '../components/ui/MysticButton';
import { useSettings } from '../hooks/useSettings';
import { useJournal } from '../hooks/useJournal';
import { useReadingSessionContext } from '../hooks/readingSessionContext';
import type { AnimationIntensity, Language } from '../types';

export function SettingsPage() {
  const { settings, update, reset } = useSettings();
  const { clearAll } = useJournal();
  const readingSession = useReadingSessionContext();
  const [confirmJournal, setConfirmJournal] = useState(false);
  const [confirmAll, setConfirmAll] = useState(false);

  const resetAllData = () => {
    reset();
    clearAll();
    readingSession.reset();
    for (let i = localStorage.length - 1; i >= 0; i -= 1) {
      const key = localStorage.key(i);
      if (key?.startsWith('the-hidden-table:')) localStorage.removeItem(key);
    }
    for (let i = sessionStorage.length - 1; i >= 0; i -= 1) {
      const key = sessionStorage.key(i);
      if (key?.startsWith('the-hidden-table:')) sessionStorage.removeItem(key);
    }
    setConfirmAll(false);
  };

  return (
    <PageTransition>
      <div className="min-h-screen px-4 py-6 md:py-8">
        <div className="max-w-lg mx-auto">
          <BackButton />
          <SectionTitle className="mt-6 mb-8">Settings</SectionTitle>

          <div className="space-y-6">
            {/* Sound */}
            <div className="glass-panel rounded-xl p-5">
              <h3 className="font-cinzel text-sm text-gold-light mb-4">Sound</h3>
              <div className="flex items-center justify-between mb-4">
                <span className="font-inter text-sm text-cream/80">Enable Sound Effects</span>
                <button type="button" role="switch" aria-checked={settings.soundEnabled} aria-label="Aktifkan efek suara" onClick={() => update({ soundEnabled: !settings.soundEnabled })}
                  className={`relative w-12 h-6 rounded-full transition-colors touch-target ${settings.soundEnabled ? 'bg-gold/40' : 'bg-cream/10'}`}>
                  <motion.div animate={{ x: settings.soundEnabled ? 24 : 2 }} transition={{ duration: 0.2 }}
                    className="absolute top-1 w-4 h-4 rounded-full bg-cream" />
                </button>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  {settings.soundEnabled ? <Volume2 className="w-4 h-4 text-gold/60" strokeWidth={1.5} /> : <VolumeX className="w-4 h-4 text-muted" strokeWidth={1.5} />}
                  <span className="font-inter text-xs text-muted">Volume</span>
                </div>
                <input type="range" min="0" max="1" step="0.1" value={settings.volume}
                  onChange={(e) => update({ volume: parseFloat(e.target.value) })}
                  className="w-full accent-gold" disabled={!settings.soundEnabled} />
              </div>
            </div>

            {/* Animation */}
            <div className="glass-panel rounded-xl p-5">
              <h3 className="font-cinzel text-sm text-gold-light mb-4">Animation</h3>
              <div className="flex items-center justify-between mb-4">
                <span className="font-inter text-sm text-cream/80">Reduce Motion</span>
                <button type="button" role="switch" aria-checked={settings.reduceMotion} aria-label="Kurangi gerakan animasi" onClick={() => update({ reduceMotion: !settings.reduceMotion })}
                  className={`relative w-12 h-6 rounded-full transition-colors touch-target ${settings.reduceMotion ? 'bg-gold/40' : 'bg-cream/10'}`}>
                  <motion.div animate={{ x: settings.reduceMotion ? 24 : 2 }} transition={{ duration: 0.2 }}
                    className="absolute top-1 w-4 h-4 rounded-full bg-cream" />
                </button>
              </div>
              <div>
                <span className="font-inter text-xs text-muted block mb-2">Animation Intensity</span>
                <div className="flex gap-2">
                  {(['low', 'normal', 'high'] as AnimationIntensity[]).map((level) => (
                    <button key={level} onClick={() => update({ animationIntensity: level })}
                      className={`flex-1 py-2 rounded-lg text-xs font-inter capitalize transition-all touch-target ${settings.animationIntensity === level ? 'bg-gold/20 border border-gold/50 text-cream' : 'bg-midnight-light/40 border border-cream/10 text-muted'}`}>{level}</button>
                  ))}
                </div>
              </div>
            </div>

            {/* Language */}
            <div className="glass-panel rounded-xl p-5">
              <h3 className="font-cinzel text-sm text-gold-light mb-4">Language</h3>
              <div className="flex gap-2">
                {(['en', 'id'] as Language[]).map((lang) => (
                  <button key={lang} onClick={() => update({ language: lang })}
                    className={`flex-1 py-2 rounded-lg text-xs font-inter uppercase transition-all touch-target ${settings.language === lang ? 'bg-gold/20 border border-gold/50 text-cream' : 'bg-midnight-light/40 border border-cream/10 text-muted'}`}>
                    {lang === 'en' ? 'English' : 'Indonesia'}
                  </button>
                ))}
              </div>
            </div>

            {/* Data */}
            <div className="glass-panel rounded-xl p-5">
              <h3 className="font-cinzel text-sm text-gold-light mb-4">Data</h3>
              <div className="flex flex-col gap-3">
                <button onClick={() => setConfirmJournal(true)}
                  className="font-inter text-sm text-muted hover:text-red-400 transition-colors text-left touch-target">Clear Reading Journal</button>
                <button onClick={() => setConfirmAll(true)}
                  className="font-inter text-sm text-muted hover:text-red-400 transition-colors text-left touch-target">Reset All Data</button>
              </div>
            </div>
          </div>
        </div>

        {/* Confirmations */}
        <AnimatePresence>
          {confirmJournal && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setConfirmJournal(false)}
              className="fixed inset-0 bg-midnight/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()} className="glass-panel rounded-2xl p-6 max-w-sm w-full text-center">
                <p className="font-cormorant text-lg text-cream/80 italic mb-6">Clear all journal entries?</p>
                <div className="flex gap-3 justify-center">
                  <MysticButton variant="ghost" onClick={() => setConfirmJournal(false)}>Cancel</MysticButton>
                  <MysticButton variant="danger" onClick={() => { clearAll(); setConfirmJournal(false); }}>Clear</MysticButton>
                </div>
              </motion.div>
            </motion.div>
          )}
          {confirmAll && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setConfirmAll(false)}
              className="fixed inset-0 bg-midnight/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()} className="glass-panel rounded-2xl p-6 max-w-sm w-full text-center">
                <p className="font-cormorant text-lg text-cream/80 italic mb-6">Reset all data? This includes settings and journal.</p>
                <div className="flex gap-3 justify-center">
                  <MysticButton variant="ghost" onClick={() => setConfirmAll(false)}>Cancel</MysticButton>
                  <MysticButton variant="danger" onClick={resetAllData}>
                    <span className="inline-flex items-center gap-1.5"><RotateCcw className="w-3.5 h-3.5" strokeWidth={1.5} /> Reset</span>
                  </MysticButton>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </PageTransition>
  );
}
