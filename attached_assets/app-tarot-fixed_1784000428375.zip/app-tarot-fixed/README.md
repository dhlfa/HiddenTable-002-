# The Hidden Table

Aplikasi tarot reflektif berbasis React, TypeScript, Vite, dan Google Apps Script.

## Deck yang digunakan

Proyek utama memakai **22 Major Arcana** (`id` 0–21), sesuai deck yang tersedia pada backend/database saat ini. Folder proyek duplikat yang sebelumnya berisi 78 kartu sudah dihapus agar deployment tidak memakai data frontend yang tidak sinkron dengan database.

## Fitur utama

- Pembacaan 1, 3, dan 5 kartu serta spread tematik.
- Pemilihan kartu yang benar-benar terhubung dengan kartu yang dibuka.
- Integrasi Apps Script melalui action `generateReading`.
- Fallback pembacaan offline ketika backend gagal.
- Jurnal pembacaan lokal.
- Kartu harian berdasarkan zona waktu Asia/Jakarta.
- Pengaturan suara, bahasa hasil AI, pengurangan gerakan, dan intensitas animasi.
- Sesi pembacaan tetap tersimpan ketika halaman tidak sengaja direfresh.
- Konfigurasi SPA untuk Vercel dan Netlify/static hosting.

## Menjalankan proyek

```bash
npm install
npm run dev
```

Build produksi:

```bash
npm run build
npm run preview
```

## Endpoint Apps Script

Endpoint lama tetap menjadi fallback agar sistem yang sudah berjalan tidak rusak. Untuk menggantinya, buat file `.env` berdasarkan `.env.example`:

```env
VITE_HIDDEN_TABLE_API_URL=https://script.google.com/macros/s/DEPLOYMENT_ID/exec
```

Payload utama yang dikirim:

```json
{
  "action": "generateReading",
  "question": "...",
  "category": "General",
  "spread": "Three Cards",
  "language": "id",
  "cards": []
}
```

Backend harus mengembalikan JSON dengan minimal `success`, `message`, `reading_id`, dan `result`.

## Penyimpanan lokal

- Pengaturan: `localStorage`
- Jurnal: `localStorage`
- Sesi aktif: `sessionStorage`
- Kartu harian: `localStorage`

Pembacaan tarot ditujukan untuk refleksi dan hiburan, bukan pengganti nasihat profesional.
